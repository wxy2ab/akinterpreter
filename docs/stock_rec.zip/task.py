import sys
import os
import re
import importlib.util
import inspect
from typing import get_type_hints

from task.recommend_refine import runner_parallel as stock_recommend_once

def find_runner_files(directory):
    runner_files = {}
    for filename in os.listdir(directory):
        if filename.endswith('.py'):
            file_path = os.path.join(directory, filename)
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    content = file.read()
            except UnicodeDecodeError:
                try:
                    with open(file_path, 'r', encoding='gbk') as file:
                        content = file.read()
                except UnicodeDecodeError:
                    print(f"Warning: Unable to read file {filename}. Skipping.")
                    continue
            
            if re.search(r'\bdef\s+runner\s*\(', content):
                runner_files[filename[:-3]] = file_path
    return runner_files

def parse_and_convert_args(func, args):
    sig = inspect.signature(func)
    type_hints = get_type_hints(func)
    converted_args = []
    converted_kwargs = {}

    for arg in args:
        if '=' in arg:
            key, value = arg.split('=', 1)
            if key in sig.parameters:
                param_type = type_hints.get(key, str)
                converted_kwargs[key] = param_type(value)
        else:
            converted_args.append(arg)

    # Convert positional arguments
    for i, (param_name, param) in enumerate(sig.parameters.items()):
        if i < len(converted_args):
            param_type = type_hints.get(param_name, str)
            converted_args[i] = param_type(converted_args[i])

    return converted_args, converted_kwargs

def load_and_run(file_path, args):
    spec = importlib.util.spec_from_file_location("module.name", file_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if hasattr(module, 'runner'):
        runner_func = module.runner
        converted_args, converted_kwargs = parse_and_convert_args(runner_func, args)
        runner_func(*converted_args, **converted_kwargs)
    else:
        print(f"Error: 'runner' function not found in {file_path}")

def main():
    task_directory = './task'
    runner_files = find_runner_files(task_directory)

    if len(sys.argv) > 1:
        func_name = sys.argv[1]
        if func_name in runner_files:
            args = sys.argv[2:]
            print(f"function name: {func_name}")
            print(f"args: {args}")
            
            load_and_run(runner_files[func_name], args)
        else:
            print(f"Error: Function '{func_name}' not found.")
    else:
        stock_recommend_once()

if __name__ == "__main__":
    main()