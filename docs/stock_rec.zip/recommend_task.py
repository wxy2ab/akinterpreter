import os
from task.recommend_refine import runner as stock_recommend_once


def job():
    # 检查是否在 GitHub Actions 环境中
    if os.getenv('GITHUB_ACTIONS') == 'true':
        stock_recommend_once(158)
    else:
        stock_recommend_once(20)

if __name__ == "__main__":
    job()