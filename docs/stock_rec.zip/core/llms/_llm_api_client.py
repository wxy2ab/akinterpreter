from abc import ABC, abstractmethod
import re
from typing import Generator, Iterator, List, Dict, Any, Union
import pandas as pd
import numpy as np
import json
from ..utils.log import logger

class LLMApiClient(ABC):
    """LLM API客户端（如Gemini）的抽象基类。"""
    @abstractmethod
    def one_chat(self, message: Union[str, List[Union[str, Any]]], is_stream: bool = False) -> Union[str, Iterator[str]]:
        """执行单次聊天交互，不使用或存储聊天历史记录。"""
        pass
    
    @abstractmethod
    def text_chat(self, message: str, is_stream: bool = False) -> Union[str, Iterator[str]]:
        """处理文本消息并返回LLM的文本响应。"""
        pass

    @abstractmethod
    def tool_chat(self, user_message: str, tools: List[Dict[str, Any]], function_module: Any, is_stream: bool = False) -> Union[str, Iterator[str]]:
        """
        处理可以访问外部工具的文本消息。这个方法需要保存和支持聊天历史。

        - `tools`：工具规范列表（字典）。
        - `function_module`：包含要调用的工具函数的模块。

        tool_chat的实现流程：
        1. 将用户消息，tools 发送给API
        2. 接收响应，处理里面的工具调用
        3. 用function_module调配合解析出的函数名和参数用工具函数
        4. 把结果返回给API
        5. 获得并返回最终响应
        """
        pass

    @abstractmethod
    def audio_chat(self, message: str, audio_path: str) -> str:
        """处理文本消息和音频文件，并返回LLM的文本响应。"""
        pass

    @abstractmethod
    def video_chat(self, message: str, video_path: str) -> str:
        """处理文本消息和视频文件，并返回LLM的文本响应。"""
        pass

    @abstractmethod
    def clear_chat(self):
        """清除聊天历史或上下文。"""
        pass

    @abstractmethod
    def get_stats(self) -> Dict[str, Any]:
        """返回使用情况统计信息（例如，token使用情况、API调用计数）。"""
        pass
    def set_system_message(self, system_message: str = "你是一个智能助手,擅长把复杂问题清晰明白通俗易懂地解答出来"):
        if not hasattr(self, "history"):
            self.history = []
        self.history = [{"role": "system", "content": system_message}]
        
    def set_parameters(self, **kwargs):
        valid_params = ["temperature", "top_p", "frequency_penalty", "presence_penalty",
                        "max_tokens", "stop", "model", "stop_sequences", "logit_bias",
                        "logprobs", "top_logprobs", "penalty_score", "max_output_tokens", "do_sample", "enable_search"]
        for key, value in kwargs.items():
            if key in valid_params:
                self.parameters[key] = value
            else:
                print(f"警告：{key} 不是有效参数，将被忽略。")