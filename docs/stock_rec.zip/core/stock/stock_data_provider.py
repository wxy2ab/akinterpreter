import csv
import json
import re
import time
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Union, Literal, Any
import os
import pickle
import logging
import akshare as ak
import ta
from core.llms._llm_api_client import LLMApiClient
import pandas as pd

from core.stock.baidu_news import BaiduFinanceAPI

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class StockDataProvider:
    def __init__(self,llm_client:LLMApiClient):
        self.llm_client = llm_client
        self.baidu_news_api = BaiduFinanceAPI()
        self.code_name_list = {}
        self.previous_trading_date_cache = None
        self.previous_trading_date_cache_time = None
        self.latest_trading_date_cache = None
        self.latest_trading_date_cache_time = None
        self.cash_flow_cache = {}
        self.profit_cache = {}
        self.balance_sheet_cache = {}
        self.forecast_cache = {}
        self.report_cache = {}
        self.comment_cache = {}
        self.historical_data_cache = {}
        self.rebound_stock_pool_cache = {}  
        self.new_stock_pool_cache = {} 
        self.strong_stock_pool_cache = {}  
        self.previous_day_stock_pool_cache = {}
        self.institutional_holdings_cache = {}
        self.big_deal_cache = {}
        self.sector_cache = {}
        self.stock_lg_code_cache = {}
        self.stock_sector_cache = {}
        self.stock_sector_update_time = None
        self.sector_cache_file_path = './json/sector.pickle'
        self.sector_cache_file_path = './json/sector.pickle'
        self.logger = logging.getLogger(__name__)
    def summarizer_news(self, news_source: list[str], query: str="总结市场热点,市场机会,市场风险", max_word: int = 240) -> str:
        """
        对给定的新闻列表进行摘要，根据指定的查询要求生成一个简洁的总结。 参数news_source: list[str], query: str="总结市场热点,市场机会,市场风险", max_word: int = 240 返回值str

        这个函数首先将新闻文本分成较小的块，然后对每个块进行摘要。如果摘要的总长度超过指定的最大字数，
        它会继续进行迭代摘要，直到得到一个不超过最大字数的最终摘要。

        参数:
        news_source (list[str]): 包含新闻文本的字符串列表。每个字符串应该是一条完整的新闻。
        query (str, 可选): 指定摘要的重点或方向。默认为"总结市场热点,市场机会,市场风险"。
        max_word (int, 可选): 最终摘要的最大字数。默认为240。

        返回:
        str: 不超过指定最大字数的新闻摘要。

        示例:
        >>> news = ["今日股市大涨，科技股领涨。", "央行宣布降息，刺激经济增长。", "新能源车企发布新品，股价应声上涨。"]
        >>> summary = stock_data_provider.summarizer_news(news, "分析今日股市表现", 100)
        >>> print(summary)
        """
        def chunk_text(text_list: list[str], max_chars: int = 10000) -> list[str]:
            chunks = []
            current_chunk = ""
            for text in text_list:
                if len(current_chunk) + len(text) <= max_chars:
                    current_chunk += text + " "
                else:
                    chunks.append(current_chunk.strip())
                    current_chunk = text + " "
            if current_chunk:
                chunks.append(current_chunk.strip())
            return chunks

        def summarize_chunk(chunk: str, query: str) -> str:
            prompt = f"请根据以下查询要求总结这段新闻内容：\n\n查询：{query}\n\n新闻内容：\n{chunk}\n\n总结："
            try:
                return self.llm_client.one_chat(prompt)
            except Exception as e:
                from core.utils.config_setting import Config
                config=Config()
                if config.has_key("glm_api_key"):
                    from core.utils.lazy import lazy
                    module=lazy("core.llms.glm_client")
                    llm_client=module.GLMClient()
                    return llm_client.one_chat(prompt)
                return chunk  # 如果出错，返回原始内容

        # 将新闻分成不超过10000字符的块
        news_chunks = chunk_text(news_source)
        
        # 对每个块进行摘要
        summaries = [summarize_chunk(chunk, query) for chunk in news_chunks]
        
        # 如果摘要总长度已经小于max_word，直接返回
        if sum(len(s) for s in summaries) <= max_word:
            return " ".join(summaries)
        
        # 否则，继续进行摘要，直到总长度不超过max_word
        while sum(len(s) for s in summaries) > max_word:
            if len(summaries) == 1:
                # 如果只剩一个摘要但仍然超过max_word，进行最后一次摘要
                final_prompt = f"请将以下摘要进一步压缩到不超过{max_word}个字：\n\n{summaries[0]}"
                return self.llm_client.one_chat(final_prompt)[:max_word]
            
            # 将现有的摘要分成两两一组进行进一步摘要
            new_summaries = []
            for i in range(0, len(summaries), 2):
                if i + 1 < len(summaries):
                    combined = summaries[i] + " " + summaries[i+1]
                    new_summary = summarize_chunk(combined, query)
                    new_summaries.append(new_summary)
                else:
                    new_summaries.append(summaries[i])
            
            summaries = new_summaries
        
        # 返回最终的摘要
        return " ".join(summaries)[:max_word]
    def get_sector_fund_flow_rank(self, indicator: str = "今日", sector_type: str = "行业资金流", top_n: int = 10) -> str:
        """
        获取板块资金流排名数据,indicator: str = "今日", sector_type: str = "行业资金流", top_n: int = 10 ，返回流向字符串

        参数:
        indicator (str): 时间范围，可选 "今日", "5日", "10日"
        sector_type (str): 板块类型，可选 "行业资金流", "概念资金流", "地域资金流"
        top_n (int): 返回前n行数据，-1 表示返回所有数据

        返回:
        str: 格式化的板块资金流排名数据
        """
        try:
            # 获取数据
            df = ak.stock_sector_fund_flow_rank(indicator=indicator, sector_type=sector_type)

            # 找到包含“涨跌幅”关键词的列名，并按照此列排序
            change_column = next((col for col in df.columns if '涨跌幅' in col), None)
            if change_column:
                df = df.sort_values(by=change_column, ascending=False)

            # 选择前 top_n 行，如果 top_n 为 -1，则选择所有行
            if top_n != -1:
                df = df.head(top_n)

            # 格式化输出
            result = f"板块资金流排名 ({sector_type} - {indicator}, Top {top_n if top_n != -1 else 'All'}):\n\n"
            for _, row in df.iterrows():
                result += f"{row['序号']}. {row['名称']} ({change_column}: {row[change_column]}%)\n"
                for col in df.columns:
                    if col not in ['序号', '名称', change_column]:
                        value = row[col]
                        # 判断数据类型来格式化输出
                        if isinstance(value, (float, int)):
                            result += f"   {col}: {value:.2f}\n"
                        else:
                            result += f"   {col}: {value}\n"
                result += "\n"

            return result
        except Exception as e:
            return f"获取板块资金流排名数据时出错: {str(e)}"
    def get_sector_fund_flow_rank_dict(self, indicator: str = "5日", sector_type: str = "行业资金流") -> Dict[str, Dict]:
        """
        获取板块资金流排名数据, indicator: str = "5日", sector_type: str = "行业资金流" ，返回流向字典
        如果结果已经缓存，则直接返回缓存的结果。

        参数:
        indicator (str): 时间范围，可选 "今日", "5日", "10日"
        sector_type (str): 板块类型，可选 "行业资金流", "概念资金流", "地域资金流"

        返回:
        Dict[str, Dict]: 以板块名称为键，行数据为值的字典
        """
        # 生成缓存的key
        cache_key = f"{indicator}_{sector_type}"

        # 如果缓存存在，则直接返回
        if cache_key in self.stock_sector_cache:
            #print(f"Returning cached data for key: {cache_key}")
            return self.stock_sector_cache[cache_key]

        try:
            # 获取数据
            df = ak.stock_sector_fund_flow_rank(indicator=indicator, sector_type=sector_type)

            # 找到包含“涨跌幅”关键词的列名，并按照此列排序
            change_column = next((col for col in df.columns if '涨跌幅' in col), None)
            if change_column:
                df = df.sort_values(by=change_column, ascending=False)

            # 将数据转换为字典格式
            result = {}
            for _, row in df.iterrows():
                row_dict = row.to_dict()
                result[row['名称']] = row_dict

            # 将结果存入缓存
            self.stock_sector_cache[cache_key] = result

            return result
        except Exception as e:
            return {"error": f"获取板块资金流排名数据时出错: {str(e)}"}

    def replace_sensitive_subtitle(self,contents:list[str])->list[str]:
        sensitive_subtitle_pair=[{"近日":"最近"}]
        # 替换敏感词
        for pair in sensitive_subtitle_pair:
            for key, value in pair.items():
                contents = [content.replace(key, value) for content in contents]
        return contents

    def get_market_news_300(self) -> List[str]:
        """
        获取财联社最新300条新闻，并将其格式化为字符串列表。
        备注：这个函数一次获取的信息很多，无法让LLM一次处理，需要调用 summarizer_news(news,query) 来蒸馏提取内容

        返回值:
            List[str]: 每个元素是一个格式化的字符串，包含新闻的标题、内容、发布日期和发布时间。

        字符串格式:
            "标题: {标题}, 内容: {内容}, 发布日期: {发布日期}, 发布时间: {发布时间}"
        """
        # 获取新闻数据并转换为字典
        news_data = ak.stock_info_global_cls().to_dict(orient="list")
        
        # 提取新闻数据，并将其格式化为字符串列表
        formatted_news_list = [
            f"标题: {title}, 内容: {content}, 发布日期: {publish_date}, 发布时间: {publish_time}"
            for title, content, publish_date, publish_time in zip(
                news_data.get("标题", []),
                news_data.get("内容", []),
                news_data.get("发布日期", []),
                news_data.get("发布时间", [])
            )
        ]
        
        return formatted_news_list
    def get_baidu_analysis_summary(self, symbol: str) -> str:
        """
        获取百度股票分析摘要。参数 symbol: str 返回 Dict[symbol,str]

        参数:
        symbol (str): 股票代码，例如 '000725'。

        返回:
        str: 格式化的字符串，包含股票的详细分析信息。
        """
        # 确定市场类型
        if symbol.startswith('HK'):
            market = 'hk'
        elif symbol.isalpha() or (symbol.isalnum() and not symbol.isdigit()):
            market = 'us'
        else:
            market = 'ab'  # 所有 A 股

        # 获取分析数据
        analysis_data = self.baidu_news_api.fetch_analysis(code=symbol, market=market)

        if analysis_data == "数据不可用":
            return "数据不可用"
        
        # 格式化结果
        formatted_analysis = (
            f"股票代码: {symbol}\n"
            f"市场: {'A股' if market == 'ab' else '港股' if market == 'hk' else '美股'}\n\n"
            f"{analysis_data}"
        )
        
        return formatted_analysis
    def summarize_historical_data(self, symbols: List[str],days: int = 180) -> dict:
        summary_dict = {}
        end_date = datetime.now().strftime("%Y%m%d")
        start_date = (datetime.now() - timedelta(days=days)).strftime("%Y%m%d")

        for symbol in symbols:
            if symbol in self.historical_data_cache:
                df = self.historical_data_cache[symbol]
            else:
                df = self.get_historical_daily_data(symbol, start_date, end_date)
                self.historical_data_cache[symbol] = df
            
            if df.empty:
                summary_dict[symbol] = "未找到数据"
                continue

            # 检查数据点是否足够
            if len(df) < 14:
                summary_dict[symbol] = f"数据点不足，仅有 {len(df)} 个数据点，无法计算所有技术指标"
                continue

            # 保留原有的指标计算
            df['MA20'] = ta.trend.sma_indicator(df['收盘'], window=min(20, len(df)))
            df['MA50'] = ta.trend.sma_indicator(df['收盘'], window=min(50, len(df)))
            df['RSI'] = ta.momentum.rsi(df['收盘'], window=min(14, len(df)))
            macd = ta.trend.MACD(df['收盘'])
            df['MACD'] = macd.macd()
            df['MACD_signal'] = macd.macd_signal()
            bb = ta.volatility.BollingerBands(df['收盘'], window=min(20, len(df)), window_dev=2)
            df['BB_upper'] = bb.bollinger_hband()
            df['BB_lower'] = bb.bollinger_lband()

            # 新增指标，确保数据点足够
            if len(df) >= 14:
                df['ATR'] = ta.volatility.average_true_range(df['最高'], df['最低'], df['收盘'], window=14)
                
                stoch = ta.momentum.StochasticOscillator(df['最高'], df['最低'], df['收盘'])
                df['Stoch_K'] = stoch.stoch()
                df['Stoch_D'] = stoch.stoch_signal()
                
                df['RSI_9'] = ta.momentum.rsi(df['收盘'], window=9)
                
                df['OBV'] = ta.volume.on_balance_volume(df['收盘'], df['成交量'])
                
                df['Momentum'] = ta.momentum.roc(df['收盘'], window=min(10, len(df)))
                
                df['ADL'] = ta.volume.acc_dist_index(df['最高'], df['最低'], df['收盘'], df['成交量'])
                
                df['Williams_R'] = ta.momentum.williams_r(high=df['最高'], low=df['最低'], close=df['收盘'], lbp=min(14, len(df)))

            # 获取数据统计（包括新增指标）
            latest_close = df['收盘'].iloc[-1]
            highest_close = df['收盘'].max()
            lowest_close = df['收盘'].min()
            avg_volume = df['成交量'].mean()
            latest_rsi = df['RSI'].iloc[-1] if 'RSI' in df else None
            latest_macd = df['MACD'].iloc[-1] if 'MACD' in df else None
            latest_macd_signal = df['MACD_signal'].iloc[-1] if 'MACD_signal' in df else None
            bb_upper = df['BB_upper'].iloc[-1] if 'BB_upper' in df else None
            bb_lower = df['BB_lower'].iloc[-1] if 'BB_lower' in df else None
            latest_atr = df['ATR'].iloc[-1] if 'ATR' in df else None
            latest_stoch_k = df['Stoch_K'].iloc[-1] if 'Stoch_K' in df else None
            latest_stoch_d = df['Stoch_D'].iloc[-1] if 'Stoch_D' in df else None
            latest_rsi_9 = df['RSI_9'].iloc[-1] if 'RSI_9' in df else None
            latest_obv = df['OBV'].iloc[-1] if 'OBV' in df else None
            latest_momentum = df['Momentum'].iloc[-1] if 'Momentum' in df else None
            latest_adl = df['ADL'].iloc[-1] if 'ADL' in df else None
            latest_williams_r = df['Williams_R'].iloc[-1] if 'Williams_R' in df else None

            # 生成描述性的字符串
            description = (
                f"股票代码: {symbol}\n"
                f"当前价格: {latest_close:.2f}\n"
                f"最高收盘价: {highest_close:.2f}\n"
                f"最低收盘价: {lowest_close:.2f}\n"
                f"平均成交量: {avg_volume:.0f}\n"
            )

            if latest_rsi is not None:
                description += f"最新RSI(14): {latest_rsi:.2f}\n"
            if latest_macd is not None and latest_macd_signal is not None:
                description += f"最新MACD: {latest_macd:.2f}\n"
                description += f"最新MACD信号线: {latest_macd_signal:.2f}\n"
            if bb_upper is not None and bb_lower is not None:
                description += f"布林带上轨: {bb_upper:.2f}\n"
                description += f"布林带下轨: {bb_lower:.2f}\n"
            if 'MA20' in df and 'MA50' in df:
                description += f"MA20: {df['MA20'].iloc[-1]:.2f}\n"
                description += f"MA50: {df['MA50'].iloc[-1]:.2f}\n"
            if latest_atr is not None:
                description += f"ATR(14): {latest_atr:.2f}\n"
            if latest_stoch_k is not None and latest_stoch_d is not None:
                description += f"随机振荡器K(14): {latest_stoch_k:.2f}\n"
                description += f"随机振荡器D(14): {latest_stoch_d:.2f}\n"
            if latest_rsi_9 is not None:
                description += f"RSI(9): {latest_rsi_9:.2f}\n"
            if latest_obv is not None:
                description += f"OBV: {latest_obv:.0f}\n"
            if latest_momentum is not None:
                description += f"价格动量(10): {latest_momentum:.2f}%\n"
            if latest_adl is not None:
                description += f"ADL: {latest_adl:.0f}\n"
            if latest_williams_r is not None:
                description += f"威廉指标(14): {latest_williams_r:.2f}"
            
            summary_dict[symbol] = description
        
        return summary_dict

    def get_index_data(self, index_symbols: List[str],start_date:str,end_date:str) -> Dict[str, pd.DataFrame]:
        """
        获取指数数据,参数index_symbols: List[str]  返回值Dict[symbol,DataFrame]
        """
        result = {}
        for index in index_symbols:
            
            data = ak.index_zh_a_hist(symbol=index,period="daily",start_date=start_date,end_date=end_date)
            result[index] = data
        return result

    def find_index_codes(self,names: List[str]) -> Dict[str, str]:
        # 获取所有指数数据
        stock_zh_index_spot_sina_df = ak.stock_zh_index_spot_sina()
        
        # 创建一个字典来存储结果
        result = {}
        
        # 将DataFrame的'名称'和'代码'列转换为字典，以便快速查找
        name_code_dict = dict(zip(stock_zh_index_spot_sina_df['名称'], stock_zh_index_spot_sina_df['代码']))
        
        # 遍历输入的名称列表
        for name in names:
            if name in name_code_dict:
                result[name] = name_code_dict[name]
        
        return result

    def summarize_historical_index_data(self, index_symbols: List[str]) -> dict:
        """
        汇总多个指数的历史数据， 参数symbols: List[str] 返回Dict[symbol,str]
        备注：上证指数：000001;上证50:000016;上证300：000300；中证1000：000852；中证500：000905；创业板指数：399006

        输入参数:
            index_symbols: List[str] 指数代码列表

        返回值:
            一个字典，键是指数代码，值是描述性的字符串。
        """
        summary_dict = {}
        end_date = datetime.now().strftime("%Y%m%d")
        start_date = (datetime.now() - timedelta(days=180)).strftime("%Y%m%d")

        for symbol in index_symbols:
            # 检查缓存
            if symbol in self.historical_data_cache:
                df = self.historical_data_cache[symbol]
            else:
                df = self.get_index_data([symbol], start_date, end_date)[symbol]
                self.historical_data_cache[symbol] = df
            
            if df.empty:
                summary_dict[symbol] = "未找到数据"
                continue

            # 获取数据统计
            latest_close = df['收盘'].iloc[-1]
            highest_close = df['收盘'].max()
            lowest_close = df['收盘'].min()
            avg_volume = df['成交量'].mean()
            std_dev = df['收盘'].std()
            median_close = df['收盘'].median()
            avg_close = df['收盘'].mean()
            return_rate = (df['收盘'].iloc[-1] - df['收盘'].iloc[0]) / df['收盘'].iloc[0] * 100

            # 生成描述性的字符串
            description = (
                f"指数代码: {symbol}\n"
                f"最新收盘价: {latest_close}\n"
                f"最近半年内最高收盘价: {highest_close}\n"
                f"最近半年内最低收盘价: {lowest_close}\n"
                f"最近半年平均成交量: {avg_volume}\n"
                f"收盘价标准差: {std_dev}\n"
                f"收盘价中位数: {median_close}\n"
                f"最近半年平均收盘价: {avg_close}\n"
                f"半年累计回报率: {return_rate:.2f}%"
            )
            
            summary_dict[symbol] = description
        
        return summary_dict    
    def stock_market_desc(self)->str:
        """
        获取市场总体描述信息，每个市场的市盈率，指数等信息。返回值str。
        """
        market_descriptions = []
        markets = ["上证", "深证", "创业板", "科创版"]
        for market in markets:
            try:
                df = ak.stock_market_pe_lg(symbol=market)
                if not df.empty:
                    latest_data = df.iloc[-1]
                    if market == "科创版":
                        description = f"{market}最新市值: {latest_data['总市值']:.2f}亿元，市盈率: {latest_data['市盈率']:.2f}"
                    else:
                        description = f"{market}最新指数: {latest_data['指数']:.2f}，平均市盈率: {latest_data['平均市盈率']:.2f}"
                    market_descriptions.append(description)
                else:
                    market_descriptions.append(f"{market}无数据")
            except Exception as e:
                market_descriptions.append(f"{market}数据获取失败: {e}")

        return "当前市场整体概况: " + "; ".join(market_descriptions)
    def get_one_stock_news(self, symbol: str, num: int = 5, days: int = 7) -> List[Dict[str, str]]:
        """
        获取指定股票的最新新闻。

        参数:
        symbol (str): 股票代码，例如 "000001" 代表平安银行
        num (int): 需要获取的新闻数量，默认为5条
        days (int): 获取最近几天的新闻，默认为7天

        返回:
        List[Dict[str, str]]: 包含新闻信息的字典列表，每个字典包含以下键：
            - 'title': 新闻标题
            - 'content': 新闻内容摘要
            - 'datetime': 新闻发布时间
            - 'url': 新闻链接（如果有）

        异常:
        ValueError: 如果无法获取股票新闻
        """
        if "." in symbol:
            symbol = symbol.split(".")[0]
        try:
            # 计算起始日期
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days)

            # 使用 akshare 获取股票新闻
            # 注意：这里假设 ak.stock_news_em 是获取新闻的正确函数，您可能需要根据实际情况调整
            df = ak.stock_news_em(symbol=symbol)

            # 过滤日期范围内的新闻
            df['datetime'] = pd.to_datetime(df['发布时间'])
            df = df[(df['datetime'] >= start_date) & (df['datetime'] <= end_date)]

            # 选择最新的 num 条新闻
            df = df.sort_values('datetime', ascending=False).head(num)

            # 构建结果列表
            news_list = []
            for _, row in df.iterrows():
                news_item = {
                    'title': row['新闻标题'],
                    'content': row['新闻内容'][:200] + '...',  # 取前200个字符作为摘要
                    'datetime': row['datetime'].strftime('%Y-%m-%d %H:%M:%S'),
                    'url': row['新闻链接'] if '新闻链接' in row else ''
                }
                news_list.append(news_item)

            return news_list

        except Exception as e:
            raise ValueError(f"无法获取股票 {symbol} 的新闻: {str(e)}")
    def get_combined_hot_stocks(self, num: int = 100) -> List[str]:
        """
        获取综合的热门股票列表，包括雪球讨论、雪球交易、问财热门、东方财富人气榜和百度热榜。

        参数:
        num (int): 从每个来源获取的股票数量，默认为100。

        返回:
        List[str]: 交叉合并后的去重股票代码列表。
        """
        symbol_dict = self.get_code_name()

        wencai = []

        # 获取各个来源的热门股票
        xueqiu_tweet = list(self.get_xueqiu_hot_tweet(num).keys())
        xueqiu_deal = list(self.get_xueqiu_hot_deal(num).keys())
        eastmoney = list(self.get_eastmoney_hot_rank(num).keys())
        baidu = list(self.get_baidu_hotrank(num=num).keys())
        try:
            wencai = list(self.get_wencai_hot_rank(num).keys())
        except Exception as e:
            pass
        
        # 将所有列表合并到一个列表中
        all_lists = [xueqiu_tweet, xueqiu_deal, eastmoney, baidu]
        if len(wencai)>0:
            all_lists.append(wencai)

        # 创建一个集合来存储已经添加的股票代码，用于去重
        seen = set()
        result = []

        # 交叉合并列表
        max_length = max(len(lst) for lst in all_lists)
        for i in range(max_length):
            for lst in all_lists:
                if i < len(lst):
                    stock = lst[i]
                    if stock not in seen and stock in symbol_dict:
                        seen.add(stock)
                        result.append(stock)

        return result
    def get_xueqiu_hot_tweet(self, num: int = 100) -> dict:
        """获取雪球讨论排行榜,参数num: int = 100，返回值Dict[symbol,str]"""
        df = ak.stock_hot_tweet_xq(symbol="最热门")
        result = {}
        for _, row in df.head(num).iterrows():
            code = self.remove_prefix(row['股票代码'])
            info = f"股票简称: {row['股票简称']}, 讨论: {row['关注']:.0f}, 最新价: {row['最新价']:.2f}"
            result[code] = info
        return result

    def get_xueqiu_hot_deal(self, num: int = 100) -> dict:
        """获取雪球交易排行榜,参数num: int = 100，返回值Dict[symbol,str]"""
        df = ak.stock_hot_deal_xq(symbol="最热门")
        result = {}
        for _, row in df.head(num).iterrows():
            code = self.remove_prefix(row['股票代码'])
            info = f"股票简称: {row['股票简称']}, 交易: {row['关注']:.0f}, 最新价: {row['最新价']:.2f}"
            result[code] = info
        return result

    def get_wencai_hot_rank(self, num: int = 100) -> dict:
        """获取问财热门股票排名,参数num: int = 100，返回值Dict[symbol,str]"""
        date = (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")  # 获取昨天的日期
        df = ak.stock_hot_rank_wc(date=date)
        result = {}
        for _, row in df.head(num).iterrows():
            code = row['股票代码']
            info = f"股票简称: {row['股票简称']}, 现价: {row['现价']:.2f}, 涨跌幅: {row['涨跌幅']:.2f}%, 热度: {row['个股热度']:.0f}, 排名: {row['个股热度排名']}"
            result[code] = info
        return result
    def get_baidu_hotrank(self, hour=7, num=20) -> dict:
        """
        获取百度热门股票排行榜。参数  hour=7, num=20 返回 Dict[symbol,str]

        参数:
        hour (int): 获取最近多少小时的数据，默认为7小时。
        num (int): 需要获取的热门股票数量，默认为20。

        返回:
        dict: 键为股票代码，值为格式化的字符串，包含热门股票的详细信息，包括排名。
        """
        # 获取当前日期
        date = datetime.now().strftime("%Y%m%d")
        
        # 获取热门股票列表
        hotlist = self.baidu_news_api.fetch_hotrank(day=date, hour=hour, rn=num)
        
        # 格式化结果
        result = {}
        for rank, item in enumerate(hotlist, 1):  # enumerate从1开始，给每个项目一个排名
            stock_info = (
                f"排名: {rank}\n"  # 添加排名信息
                f"股票名称: {item['name']}\n"
                f"当前价格: {item['price']}\n"
                f"涨跌幅: {item['change']}\n"
                f"所属板块: {item['sector']}\n"
                f"排名变化: {item['rank_change']}\n"
                f"地区: {item['region']}\n"
                f"热度: {item['heat']}\n"
                f"----------------------"
            )
            result[item['code']] = stock_info
        
        return result
    def remove_prefix(self,code: str) -> str:
        """移除股票代码的前缀"""
        return code.lstrip('SH').lstrip('SZ').lstrip('BJ')
    def get_eastmoney_hot_rank(self, num: int = 100) -> dict:
        """获取东方财富人气榜-A股,参数num: int = 100，返回值Dict[symbol,str]"""
        df = ak.stock_hot_rank_em()
        result = {}
        for _, row in df.head(num).iterrows():
            code = self.remove_prefix(row['代码'])
            info = f"股票名称: {row['股票名称']}, 最新价: {row['最新价']:.2f}, 涨跌额: {row['涨跌额']:.2f}, 涨跌幅: {row['涨跌幅']:.2f}%"
            result[code] = info
        return result
    def get_stock_sector(self, symbol: str) -> str:
        if not self.sector_cache:
            self._load_sector_cache()
        if not self.sector_cache:
            self._update_sector_cache()
        return self.sector_cache.get(symbol, "未找到所属行业")
    def get_market_news_300_update(self, since: Optional[datetime] = None) -> Tuple[List[str], Optional[datetime]]:
        """
        获取 get_market_news_300 的新闻更新,返回值Tuple[List[str], Optional[datetime]]
        """
        news_data = ak.stock_info_global_cls()
        
        if news_data.empty:
            return [], None
        
        data = news_data if since is None else news_data[news_data["发布时间"] > since.time()]
        
        if data.empty:
            return [], since  # 如果没有新数据，返回空列表和原始的since时间

        dict_data = data.to_dict(orient="list")
        formatted_news_list = [
            f"标题: {title}, 内容: {content}, 发布日期: {publish_date}, 发布时间: {publish_time}"
            for title, content, publish_date, publish_time in zip(
                dict_data.get("标题", []),
                dict_data.get("内容", []),
                dict_data.get("发布日期", []),
                dict_data.get("发布时间", [])
            )
        ]
        
        # 将最后一条新闻的日期和时间转换为datetime对象
        try:
            last_date = data.iloc[-1]["发布日期"]
            last_time = data.iloc[-1]["发布时间"]
            
            # 确保 last_date 是 date 对象，last_time 是 time 对象
            if isinstance(last_date, str):
                last_date = datetime.strptime(last_date, "%Y-%m-%d").date()
            if isinstance(last_time, str):
                last_time = datetime.strptime(last_time, "%H:%M:%S").time()
            
            last_datetime = datetime.combine(last_date, last_time)
        except (IndexError, KeyError, ValueError) as e:
            last_datetime = datetime.now()

        return formatted_news_list, last_datetime
    def _load_sector_cache(self):
        try:
            if os.path.exists(self.sector_cache_file_path):
                with open(self.sector_cache_file_path, 'rb') as f:
                    self.sector_cache = pickle.load(f)
                self.logger.info(f"Loaded {len(self.sector_cache)} items from sector cache.")
            else:
                self.logger.info("Sector cache file does not exist. Will create a new one.")
        except Exception as e:
            self.logger.error(f"Error loading sector cache: {str(e)}")
            self.sector_cache = {}

    def _update_sector_cache(self):
        try:
            industry_df = ak.stock_board_industry_name_em()
            new_cache = {}
            for _, industry in industry_df.iterrows():
                industry_code = industry['板块代码']
                industry_name = industry['板块名称']
                try:
                    cons_df = ak.stock_board_industry_cons_em(symbol=industry_name)
                    for code in cons_df['代码'].values:
                        code_str = str(code)
                        if code_str in new_cache:
                            new_cache[code_str] += f", {industry_name}"
                        else:
                            new_cache[code_str] = industry_name
                except Exception as e:
                    self.logger.warning(f"Error fetching constituents for industry {industry_name}: {str(e)}")
            self.sector_cache = new_cache
            self._save_sector_cache()
            self.stock_sector_update_time = datetime.now()
            self.logger.info(f"Updated sector cache with {len(self.sector_cache)} items.")
        except Exception as e:
            self.logger.error(f"Error updating sector cache: {str(e)}")

    def _save_sector_cache(self):
        try:
            with open(self.sector_cache_file_path, 'wb') as f:
                pickle.dump(self.sector_cache, f)
            self.logger.info(f"Saved {len(self.sector_cache)} items to sector cache file.")
        except Exception as e:
            self.logger.error(f"Error saving sector cache: {str(e)}")

    def get_code_name(self) -> Dict[str, str]:
        if self.code_name_list and len(self.code_name_list)>0:
            return self.code_name_list  
        spot = ak.stock_info_a_code_name()
        for index, row in spot.iterrows():
            self.code_name_list[row["code"]] = row["name"]
        return self.code_name_list 

    def is_stock(self,symbol:str)->bool:
        return symbol in self.get_code_name()

    def get_stock_a_indicators(self, symbol: str) -> str:
        if len(self.stock_lg_code_cache) == 0:
            df = ak.stock_a_indicator_lg(symbol="all")
            for _, row in df.iterrows():
                self.stock_lg_code_cache[row['code']] = row['stock_name']
        if symbol not in self.stock_lg_code_cache:
            return f"股票代码{symbol}暂无数据"
        data = ak.stock_a_indicator_lg(symbol=symbol)
        latest_data = data.iloc[-1]
        stock_indicators_info = (
            f"A股个股指标"
            f"股票代码: {symbol} 的最新A股个股指标: "
            f"市盈率: {latest_data['pe']}, "
            f"市盈率TTM: {latest_data['pe_ttm']}, "
            f"市净率: {latest_data['pb']}, "
            f"市销率: {latest_data['ps']}, "
            f"市销率TTM: {latest_data['ps_ttm']}, "
            f"股息率: {latest_data['dv_ratio']}, "
            f"股息率TTM: {latest_data['dv_ttm']}, "
            f"总市值: {latest_data['total_mv']}"
        )
        return stock_indicators_info

    def get_historical_daily_data(self, symbol: str, start_date: str, end_date: str) -> pd.DataFrame:
        return ak.stock_zh_a_hist(symbol=symbol,period="daily", start_date=start_date, end_date=end_date)

    def get_stock_info(self,symbol: str) -> str:
        stock_info_df = ak.stock_individual_info_em(symbol=symbol)
        stock_info_str = "\n".join([f"{row['item']}: {row['value']}" for _, row in stock_info_df.iterrows()])
        return stock_info_str

    def get_stock_fund_flow(self, indicator: Literal[ "即时", "3日排行", "5日排行", "10日排行", "20日排行"]="即时") -> Dict[str, Dict]:
        stock_fund_flow_individual_df = ak.stock_fund_flow_individual(symbol=indicator)
        result = {}
        for _, row in stock_fund_flow_individual_df.iterrows():
            stock_code = row['股票代码']
            row_dict = row.to_dict()
            result[stock_code] = row_dict
        return result

    def get_stock_comments_dataframe(self)->pd.DataFrame:
        return ak.stock_comment_em()

    def get_mainbussiness_mid(self,symbol:str)->pd.DataFrame:
        return ak.stock_zygc_ym(symbol=symbol)

    def get_manager_talk(self,symbol:str)->pd.DataFrame:
        return ak.stock_mda_ym(symbol)

    def _extract_code(self, response):
        code_pattern = r'```python\s*(.*?)\s*```'
        matches = re.findall(code_pattern, response, re.DOTALL)
        if matches:
            return matches[0].strip()
        else:
            return ""

    def extract_json_from_text(self, text: str, max_attempts: int = 4) -> Union[Dict[str, Any], List[Dict[str, Any]]]:
        json_match = re.search(r'```json\s*([\s\S]*?)\s*```', text)
        if not json_match:
            json_match = re.search(r'\{[\s\S]*\}', text)
        if not json_match:
            json_match = re.search(r'\[[\s\S]*\]', text)
        
        if json_match:
            json_str = json_match.group(1) if '```json' in json_match.group() else json_match.group()
            json_str = json_str.replace("'", "\"")
            
            for attempt in range(max_attempts):
                try:
                    return json.loads(json_str, strict=False)
                except Exception as err:
                    if attempt == max_attempts - 1:
                        raise err
                    
                    fix_prompt = f"""
                    以下JSON字符串解析时发生错误：

                    ```json
                    {json_str}
                    ```

                    错误信息：{str(err)}

                    请帮我修复这个JSON。要求：

                    尽可能保持原始数据不变。
                    只修复导致解析错误的问题，不要改变有效的数据结构和值。
                    特别注意检查并修复以下常见问题：
                    缺少逗号
                    多余的逗号
                    未闭合的引号
                    未闭合的括号
                    双斜杠注释
                    内部嵌套的引号冲突（请将内层引号改为不同符号或使用转义字符）
                    如果有多个错误，请尝试一次性修复所有错误。
                    返回修复后的完整JSON，用```json  ```包裹。
                    不要添加任何解释，只返回修复后的JSON。
                    """
                    
                    response = self.llm_client.one_chat(fix_prompt)
                    json_match = re.search(r'```json\s*([\s\S]*?)\s*```', response)
                    if json_match:
                        json_str = json_match.group(1)
                    else:
                        json_str = response
                    json_str = json_str.replace("'", "\"")
        
        raise json.JSONDecodeError("No valid JSON found in the text", text, 0)