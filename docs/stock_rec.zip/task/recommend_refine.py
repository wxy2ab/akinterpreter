import csv
import json
import re
import time
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
import os
import pickle
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class DataManager:
    def __init__(self, file_path: str = "./output/market_data.pkl"):
        self.file_path = file_path
        self.last_news_time = None
        self.last_hot_stocks_time = None
        self.last_market_info_time = None
        self.analyzed_stocks = {}
        self.market_hotspots = []
        self.hot_stocks = []
        self.market_info = {}

    def load_data(self):
        if os.path.exists(self.file_path):
            with open(self.file_path, 'rb') as f:
                data = pickle.load(f)
                self.__dict__.update(data)

    def save_data(self):
        with open(self.file_path, 'wb') as f:
            pickle.dump(self.__dict__, f)

    def update_news(self, news: List[str], last_news_time: datetime):
        self.market_hotspots = news
        self.last_news_time = last_news_time

    def update_hot_stocks(self, hot_stocks: List[str]):
        self.hot_stocks = hot_stocks
        self.last_hot_stocks_time = datetime.now()

    def update_market_info(self, market_info: dict):
        self.market_info = market_info
        self.last_market_info_time = datetime.now()

    def update_analyzed_stock(self, stock: str, analysis: dict):
        self.analyzed_stocks[stock] = {
            'analysis': analysis,
            'last_analysis_time': datetime.now()
        }

def get_market_info(stock_data_provider):
    market_overview = stock_data_provider.stock_market_desc()
    market_news = stock_data_provider.get_market_news_300()
    market_news = stock_data_provider.replace_sensitive_subtitle(market_news)
    sector_performance = stock_data_provider.get_sector_fund_flow_rank()
    market_news_summary = stock_data_provider.summarizer_news(market_news, """
    1. 总结最新的市场热点和主题，特别关注：
       a) 最新的政策动向及其可能带来的投资机会
       b) 行业重大事件或突破性进展
       c) 资金流向明显的板块
    2. 分析这些热点可能对哪些行业或板块产生影响
    3. 识别市场情绪和投资者关注的焦点
    4. 总结可能影响短期市场走势的关键因素
    5. 对比前期热点，分析热点的延续性和转换
    请以简洁、结构化的方式呈现以上信息。
    """)
    index_trend = stock_data_provider.summarize_historical_index_data(['000001'])
    
    return {
        'market_overview': market_overview,
        'market_news_summary': market_news_summary,
        'sector_performance': sector_performance,
        'index_trend': index_trend
    }

def analyze_stocks(stock_data_provider, hot_stocks):
    stock_analysis = {}
    for stock in hot_stocks:
        stock_analysis[stock] = {
            'code': stock,
            'name': stock_data_provider.get_code_name()[stock],
            'info': stock_data_provider.get_stock_info(stock),
            'indicators': stock_data_provider.get_stock_a_indicators(stock),
            'history': stock_data_provider.summarize_historical_data([stock])[stock],
            'baidu_analysis': stock_data_provider.get_baidu_analysis_summary(stock),
            'news': stock_data_provider.get_one_stock_news(stock, num=3),
            'sector': stock_data_provider.get_stock_sector(stock),
        }
    return stock_analysis

def evaluate_basic_info(llm_client, stock_code, stock_data, data_provider):
    prompt = f"""
    请对股票{stock_data['name']}({stock_code})的基本面进行分析，考虑以下因素：
    1. 股票信息：{stock_data['info']}
    2. 股票指标：{stock_data['indicators']}
    3. 百度分析摘要：{stock_data['baidu_analysis']}

    返回JSON格式，包含：
    - 'financial_health': 财务健康状况（0-100的整数）
    - 'growth_potential': 增长潜力（0-100的整数）
    - 'valuation': 估值水平（低估/合理/高估）
    - 'key_strengths': 主要优势（列出不超过2点）
    - 'key_weaknesses': 主要劣势（列出不超过2点）
    - 'summary': 基本面总结（不超过80字）
    """
    response = llm_client.one_chat(prompt)
    return data_provider.extract_json_from_text(response)

def evaluate_technical_analysis(llm_client, stock_data, data_provider):
    prompt = f"""
    请对股票{stock_data['name']}的技术面进行简要分析，考虑以下因素：
    1. 历史数据摘要：{stock_data['history']}

    返回JSON格式，包含：
    - 'trend': 当前趋势（上升/震荡/下降）
    - 'strength': 趋势强度（0-100的整数）
    - 'support_level': 主要支撑位
    - 'resistance_level': 主要压力位
    - 'summary': 技术面总结（不超过50字）
    """
    response = llm_client.one_chat(prompt)
    return data_provider.extract_json_from_text(response)

def evaluate_market_environment(llm_client, stock_data, market_info, data_provider):
    all_sector_data = data_provider.get_sector_fund_flow_rank_dict(indicator="今日")
    target_sector_data = all_sector_data.get(stock_data['sector'], {})
    formatted_sector_data = str(target_sector_data) if target_sector_data else "未找到具体行业数据"

    prompt = f"""
    请简要分析{stock_data['name']}（股票代码：{stock_data['code']}）在当前市场环境中的表现，考虑以下因素：

    1. 市场整体情况：
    {market_info['market_overview']}

    2. {stock_data['name']}所属行业（{stock_data['sector']}）的今日表现：
    {formatted_sector_data}

    3. 主要指数近期走势：
    {market_info['index_trend']}

    4. 市场热点和新闻摘要：
    {market_info['market_news_summary']}

    请基于以上信息，针对{stock_data['name']}进行分析，返回JSON格式，包含：
    - 'market_correlation': {stock_data['name']}与大盘相关性（高/中/低）
    - 'sector_performance': {stock_data['sector']}行业今日表现（领先/跟随/落后）
    - 'hot_spot_relevance': {stock_data['name']}与市场热点相关度（0-100的整数）
    - 'policy_impact': 政策对{stock_data['name']}的影响（正面/中性/负面）
    - 'summary': 今日市场环境对{stock_data['name']}的影响总结（不超过80字）
    """
    response = llm_client.one_chat(prompt)
    return data_provider.extract_json_from_text(response)

def evaluate_stock_specific(llm_client, stock_data, data_provider):
    prompt = f"""
    请简要分析{stock_data['name']}的特定情况，考虑以下因素：
    1. 个股新闻：
    {stock_data['news']}

    返回JSON格式，包含：
    - 'news_sentiment': 新闻情绪（正面/中性/负面）
    - 'news_impact': 新闻影响力（0-100的整数）
    - 'potential_catalysts': 潜在催化剂（列出不超过2点）
    - 'risk_factors': 风险因素（列出不超过2点）
    - 'summary': 股票特定情况总结（不超过50字）
    """
    response = llm_client.one_chat(prompt)
    return data_provider.extract_json_from_text(response)

def evaluate_single_stock(llm_client, stock_data_provider, stock_code, stock_data, market_info):
    basic_eval = evaluate_basic_info(llm_client, stock_code, stock_data, stock_data_provider)
    technical_eval = evaluate_technical_analysis(llm_client, stock_data, stock_data_provider)
    market_eval = evaluate_market_environment(llm_client, stock_data, market_info, stock_data_provider)
    specific_eval = evaluate_stock_specific(llm_client, stock_data, stock_data_provider)
    
    return combine_evaluations(basic_eval, technical_eval, market_eval, specific_eval)

def calculate_base_score(basic_eval, technical_eval, market_eval, specific_eval):
    financial_score = (safe_int(basic_eval.get('financial_health', 0)) + 
                       safe_int(basic_eval.get('growth_potential', 0))) / 2 * 0.3
    technical_score = safe_int(technical_eval.get('strength', 0)) * 0.2
    market_score = (
        (100 if "高" in market_eval.get('market_correlation', '') else 50 if "中" in market_eval.get('market_correlation', '') else 0) +
        (100 if "领先" in market_eval.get('sector_performance', '') else 50 if "跟随" in market_eval.get('sector_performance', '') else 0) +
        safe_int(market_eval.get('hot_spot_relevance', 0))
    ) / 3 * 0.3
    specific_score = (
        (100 if "正面" in specific_eval.get('news_sentiment', '') else 50 if "中性" in specific_eval.get('news_sentiment', '') else 0) +
        safe_int(specific_eval.get('news_impact', 0))
    ) / 2 * 0.2
    
    total_score = financial_score + technical_score + market_score + specific_score
    return min(100, max(0, total_score))

def safe_int(value, default=0):
    try:
        return int(value)
    except (ValueError, TypeError):
        return default

def combine_evaluations(basic_eval, technical_eval, market_eval, specific_eval):
    base_score = calculate_base_score(basic_eval, technical_eval, market_eval, specific_eval)
    return {
        'base_score': base_score,
        'evaluation_details': {**basic_eval, **technical_eval, **market_eval, **specific_eval}
    }

def generate_final_report(market_info, recommended_stocks, llm_client, n: int = 10) -> str:
    report = f"# Top {n} Analyzed Stocks Report\n\n"
    report += f"## 市场整体情况概述\n\n{market_info['market_overview']}\n\n"
    report += f"## 市场热点和主题\n\n{market_info['market_news_summary']}\n\n"
    report += f"## 行业板块表现\n\n{market_info['sector_performance']}\n\n"
    report += f"## 推荐的短线股票列表\n\n"
    
    for rank, stock_data in enumerate(recommended_stocks[:n], 1):
        stock_code = stock_data.get('code')
        stock_name = stock_data.get('name', '未知')
        base_score = stock_data.get('base_score', 0)
        
        report += f"### {rank}. {stock_name} ({stock_code}) - 评分: {base_score:.2f}\n\n"
        evaluation_details = stock_data.get('evaluation_details', {})
        if evaluation_details:
            report += f"- 基本面概述: {evaluation_details.get('summary', 'N/A')}\n"
            report += f"- 技术面: {evaluation_details.get('trend', 'N/A')}，支撑位: {evaluation_details.get('support_level', 'N/A')}，压力位: {evaluation_details.get('resistance_level', 'N/A')}\n"
            report += f"- 市场环境影响: {evaluation_details.get('summary', 'N/A')}\n"
        report += "\n"
    
    report += f"### 短线操作建议和风险提示\n\n"
    report += "投资者在考虑短线操作时，应关注市场整体情况和热点主题，同时注意行业板块表现。推荐股票虽有较高的评分，但需谨慎对待。务必关注市场波动风险，以及可能影响短期市场走势的地缘政治紧张局势、自然灾害和宏观政策等因素。\n"

    prompt = f"""
    请根据以下内容生成一个专业的Markdown格式的股票推荐报告：
    
    {report}
    
    重点强调：
    1. 市场整体情况。
    2. 市场热点和主题。
    3. 行业板块表现。
    4. 推荐股票的评分和简要分析。
    5. 提供短线操作建议和风险提示。
    
    报告的语言应简洁明了，细节适中。适合投资者阅读。
    """
    
    final_report = llm_client.one_chat(prompt)
    return final_report

def save_report(report):
    directory = './markdown/stock_recommend'
    if not os.path.exists(directory):
        os.makedirs(directory)
    current_time = datetime.now()
    file_name = f"stock_recommend_{current_time.strftime('%Y%m%d_%H%M%S')}.md"
    file_path = os.path.join(directory, file_name)

    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(report)

    print(f"Report saved to: {file_path}")

def runner(rank_num:int=20, report_num:int=10):
    from core.llms.fallback_client import FallbackLLMClient
    from core.stock.stock_data_provider import StockDataProvider

    llm_client = FallbackLLMClient()
    stock_data_provider = StockDataProvider(llm_client)
    news, last_news_time = stock_data_provider.get_market_news_300_update()
    hot_stocks_dict = stock_data_provider.get_combined_hot_stocks(num=rank_num)
    market_info = get_market_info(stock_data_provider)
    analysis = {}
    total_stocks = len(hot_stocks_dict)
    processed_stocks = 0
    for stock in hot_stocks_dict:
        processed_stocks += 1
        if not stock_data_provider.is_stock(stock):
            continue
        print(f"Analyzing stock: {stock} ({processed_stocks}/{total_stocks})")
        analysis[stock] = analyze_stock(stock_data_provider, stock, market_info, news)
        analysis[stock]['code'] = stock
        analysis[stock]['name'] = stock_data_provider.get_code_name()[stock]

    top_stocks = sorted(analysis.values(), key=lambda x: x['base_score'], reverse=True)
    report = generate_final_report(market_info, top_stocks, llm_client, report_num)
    save_report(report)

def analyze_stock(stock_data_provider, stock, market_info, market_hotspots):
    logger.info(f"Analyzing stock: {stock}")
    
    if market_hotspots:
        market_info['market_hotspots'] = market_hotspots

    stock_data = analyze_stocks(stock_data_provider, [stock])[stock]
    llm_client = stock_data_provider.llm_client
    evaluation = evaluate_single_stock(llm_client, stock_data_provider, stock, stock_data, market_info)
    
    return evaluation

if __name__ == "__main__":
    runner()